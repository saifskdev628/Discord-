# Discord Bot with Dashboard

### ميزات المشروع
- بوت ديسكورد مع نظام بسيط للترحيب
- لوحة تحكم مبدئية باستخدام Express وEJS

### تشغيل المشروع
1. نسخ ملف `.env.example` إلى `.env` وتعديل القيم.
2. تشغيل:
```bash
npm install
npm start
```
3. فتح لوحة التحكم على `http://localhost:3000`